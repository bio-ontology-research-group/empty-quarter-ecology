import numpy as np
import pandas as pd
from scipy.spatial.distance import pdist, squareform

POSITION_FILE = "well_positions.csv"
META_FILE = "analysis/batch-adjacency-2026-09-07/batch_meta.tsv"
FEATURE_TABLE = "rubalkhali-kg-3.0.0-source/data/metadata/taxonomy/feature-table-trips1-5.tsv"
WELLS_OUT = "results/wells.tsv"
BC_OUT = "results/bc_matrix.tsv"

# --- Build well table ---
pos = pd.read_csv(POSITION_FILE)
pos["sid"] = "e" + pos["Sample"].str.split("_").str[:2].str.join("_")
pos = pos.drop_duplicates("sid", keep="first")  # libraries plated twice: keep the first listed well
pos["row"] = pos["Position"].str[0].map(lambda c: ord(c) - ord("A"))
pos["col"] = pos["Position"].str[1:].astype(int)
meta = pd.read_csv(META_FILE, sep="\t")
wells = pos.merge(meta, left_on="sid", right_on="profile", how="inner")
wells = wells[["sid", "Plate", "Position", "row", "col", "site", "compartment", "lat", "lon", "dna_conc", "dna_kit"]]
print(f"{len(wells)} wells mapped, {wells.sid.nunique()} unique samples, dropped {len(pos) - len(wells)} unmapped")

# --- Stream feature table, keeping only plated samples ---
sids = sorted(wells.sid.unique())
with open(FEATURE_TABLE) as f:
    f.readline()
    header = f.readline().rstrip("\n").split("\t")
usecols = [0] + [header.index(s) for s in sids]
chunks = []
dtypes = {s: np.float32 for s in sids}
for chunk in pd.read_csv(FEATURE_TABLE, sep="\t", skiprows=1, usecols=usecols, index_col=0, dtype=dtypes, chunksize=50000):
    chunk = chunk.loc[chunk.sum(axis=1) > 0]  # drop features absent from all plated samples
    chunks.append(chunk)
ft = pd.concat(chunks)[sids]
print(f"feature table subset: {ft.shape[0]} features x {ft.shape[1]} samples")

# --- Bray-Curtis on relative abundance ---
X = ft.T.to_numpy(dtype=np.float64)
depth = X.sum(axis=1)
print(f"read depth: min={depth.min():.0f} median={np.median(depth):.0f} max={depth.max():.0f}")
X = X / depth[:, None]
bc = squareform(pdist(X, metric="braycurtis"))
bc_df = pd.DataFrame(bc, index=sids, columns=sids)

# --- Save ---
import os; os.makedirs("results", exist_ok=True)
wells.to_csv(WELLS_OUT, sep="\t", index=False)
bc_df.to_csv(BC_OUT, sep="\t")
print(f"saved {WELLS_OUT}, {BC_OUT}")
